<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Am extends REST_Controller {

	public function __construct() {
		parent::__construct();

		$this->load->library('sapinterfacer');
		$this->sapinterfacer->set_object(540000006);
	}

	public function add_activity_post() {
		$addList = $this->post();
		
		$sapInfResponse = $this->sapinterfacer->_add($updatedList);

		if ($sapInfResponse) {
			$this->response(array('message'=>'Activity Transfer Successfully Added'), 200);
		} else {
			$this->response(array('message'=>$this->sapinterfacer->errMsg), 200);
		}
	}

	public function update_activity_put() {
		$updatedList = $this->put();

		$sapInfResponse = $this->sapinterfacer->_update($updatedList,1,'DocEntry');

		if ($sapInfResponse) {
			$transfer =  $this->sapinterfacer->get_object();
			$this->response(array('message'=>'Activity '.$transfer->DocNum.'(DocNum) has been Successfully Updated'), 200);
		} else {
			$this->response(array('message'=>$this->sapinterfacer->errMsg), 200);
		}
	}

}

/* End of file am.php */
/* Location: ./application/controllers/api/am.php */