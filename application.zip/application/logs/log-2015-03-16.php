<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-16 10:12:06 --> Severity: Notice  --> Undefined property: CI_Config::$load C:\xampp\htdocs\service\system\core\Loader.php 599
ERROR - 2015-03-16 10:32:27 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 460
ERROR - 2015-03-16 10:32:27 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 468
ERROR - 2015-03-16 10:32:27 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\xampp\htdocs\service\application\core\REST_Controller.php 488
ERROR - 2015-03-16 10:32:27 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\service\application\core\REST_Controller.php 497
ERROR - 2015-03-16 10:32:30 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 460
ERROR - 2015-03-16 10:32:30 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 468
ERROR - 2015-03-16 10:32:30 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\xampp\htdocs\service\application\core\REST_Controller.php 488
ERROR - 2015-03-16 10:32:30 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\service\application\core\REST_Controller.php 497
ERROR - 2015-03-16 10:32:45 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 460
ERROR - 2015-03-16 10:32:45 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 468
ERROR - 2015-03-16 10:32:45 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\xampp\htdocs\service\application\core\REST_Controller.php 488
ERROR - 2015-03-16 10:32:45 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\service\application\core\REST_Controller.php 497
ERROR - 2015-03-16 10:32:46 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 460
ERROR - 2015-03-16 10:32:46 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 468
ERROR - 2015-03-16 10:32:46 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\xampp\htdocs\service\application\core\REST_Controller.php 488
ERROR - 2015-03-16 10:32:46 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\service\application\core\REST_Controller.php 497
ERROR - 2015-03-16 10:32:58 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 455
ERROR - 2015-03-16 10:32:58 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 463
ERROR - 2015-03-16 10:32:58 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\xampp\htdocs\service\application\core\REST_Controller.php 483
ERROR - 2015-03-16 10:32:58 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\service\application\core\REST_Controller.php 492
ERROR - 2015-03-16 10:32:58 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 455
ERROR - 2015-03-16 10:32:58 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 463
ERROR - 2015-03-16 10:32:58 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\xampp\htdocs\service\application\core\REST_Controller.php 483
ERROR - 2015-03-16 10:32:58 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\service\application\core\REST_Controller.php 492
ERROR - 2015-03-16 10:33:56 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 455
ERROR - 2015-03-16 10:33:56 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 463
ERROR - 2015-03-16 10:33:56 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\xampp\htdocs\service\application\core\REST_Controller.php 483
ERROR - 2015-03-16 10:33:56 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\service\application\core\REST_Controller.php 492
ERROR - 2015-03-16 10:34:39 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 455
ERROR - 2015-03-16 10:34:39 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 463
ERROR - 2015-03-16 10:34:39 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\xampp\htdocs\service\application\core\REST_Controller.php 483
ERROR - 2015-03-16 10:34:39 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\service\application\core\REST_Controller.php 492
ERROR - 2015-03-16 10:36:27 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 455
ERROR - 2015-03-16 10:36:27 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 463
ERROR - 2015-03-16 10:36:27 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\xampp\htdocs\service\application\core\REST_Controller.php 483
ERROR - 2015-03-16 10:36:27 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\service\application\core\REST_Controller.php 492
