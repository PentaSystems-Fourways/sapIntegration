<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-24 09:44:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4
ERROR - 2015-03-24 09:45:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4
ERROR - 2015-03-24 10:31:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\service\application\core\REST_Controller.php:423) C:\xampp\htdocs\service\application\core\REST_Controller.php 477
ERROR - 2015-03-24 10:31:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\service\application\core\REST_Controller.php:423) C:\xampp\htdocs\service\system\core\Common.php 441
ERROR - 2015-03-24 10:31:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\service\application\core\REST_Controller.php:423) C:\xampp\htdocs\service\application\core\REST_Controller.php 495
ERROR - 2015-03-24 10:31:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\service\application\core\REST_Controller.php:425) C:\xampp\htdocs\service\application\core\REST_Controller.php 480
ERROR - 2015-03-24 10:31:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\service\application\core\REST_Controller.php:425) C:\xampp\htdocs\service\system\core\Common.php 441
ERROR - 2015-03-24 10:31:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\service\application\core\REST_Controller.php:425) C:\xampp\htdocs\service\application\core\REST_Controller.php 498
ERROR - 2015-03-24 14:00:59 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\service\application\controllers\api\scenario.php 47
ERROR - 2015-03-24 14:49:59 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\service\application\models\scenario_model.php 15
ERROR - 2015-03-24 14:49:59 --> Query error: Unknown column 'Array' in 'field list'
ERROR - 2015-03-24 14:50:48 --> Query error: Column count doesn't match value count at row 1
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:54:31 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:56:24 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 14:58:12 --> Severity: Warning  --> implode(): Invalid arguments passed C:\xampp\htdocs\service\application\controllers\api\scenario.php 61
ERROR - 2015-03-24 15:01:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '7,6,5,,,269)' at line 1
ERROR - 2015-03-24 16:04:56 --> Severity: Notice  --> Undefined variable: areas C:\xampp\htdocs\service\application\models\scenario_model.php 23
ERROR - 2015-03-24 16:04:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4
ERROR - 2015-03-24 16:05:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4
ERROR - 2015-03-24 16:05:47 --> Severity: Notice  --> Undefined variable: areas C:\xampp\htdocs\service\application\models\scenario_model.php 23
ERROR - 2015-03-24 16:05:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 4
ERROR - 2015-03-24 16:06:02 --> Query error: Unknown column 'a.type' in 'field list'
