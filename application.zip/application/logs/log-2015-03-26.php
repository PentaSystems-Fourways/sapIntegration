<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-26 12:45:32 --> Severity: Notice  --> Undefined variable: male C:\xampp\htdocs\service\application\controllers\api\scenario.php 71
ERROR - 2015-03-26 12:45:32 --> Severity: Notice  --> Undefined variable: area_primary C:\xampp\htdocs\service\application\controllers\api\scenario.php 78
ERROR - 2015-03-26 12:46:26 --> Severity: Notice  --> Undefined variable: area_primary C:\xampp\htdocs\service\application\controllers\api\scenario.php 78
ERROR - 2015-03-26 12:47:11 --> Severity: Notice  --> Undefined variable: area_primary C:\xampp\htdocs\service\application\controllers\api\scenario.php 89
ERROR - 2015-03-26 12:47:11 --> Severity: Notice  --> Undefined variable: area_primary C:\xampp\htdocs\service\application\controllers\api\scenario.php 89
ERROR - 2015-03-26 12:47:17 --> Severity: Notice  --> Undefined variable: area_primary C:\xampp\htdocs\service\application\controllers\api\scenario.php 89
ERROR - 2015-03-26 12:47:17 --> Severity: Notice  --> Undefined variable: area_primary C:\xampp\htdocs\service\application\controllers\api\scenario.php 89
ERROR - 2015-03-26 12:47:42 --> Severity: Notice  --> Undefined variable: area_primary C:\xampp\htdocs\service\application\controllers\api\scenario.php 89
ERROR - 2015-03-26 12:47:42 --> Severity: Notice  --> Undefined variable: area_primary C:\xampp\htdocs\service\application\controllers\api\scenario.php 89
ERROR - 2015-03-26 12:47:49 --> Severity: Notice  --> Undefined variable: area_primary C:\xampp\htdocs\service\application\controllers\api\scenario.php 89
ERROR - 2015-03-26 12:47:49 --> Severity: Notice  --> Undefined variable: area_primary C:\xampp\htdocs\service\application\controllers\api\scenario.php 89
ERROR - 2015-03-26 12:48:47 --> Severity: Notice  --> Undefined variable: area_primary C:\xampp\htdocs\service\application\controllers\api\scenario.php 86
ERROR - 2015-03-26 12:48:47 --> Severity: Notice  --> Undefined variable: area_primary C:\xampp\htdocs\service\application\controllers\api\scenario.php 86
ERROR - 2015-03-26 12:51:07 --> Severity: Notice  --> Undefined variable: male C:\xampp\htdocs\service\application\controllers\api\scenario.php 67
ERROR - 2015-03-26 12:56:41 --> Severity: Notice  --> Undefined variable: area_primary C:\xampp\htdocs\service\application\controllers\api\scenario.php 86
ERROR - 2015-03-26 12:56:41 --> Severity: Notice  --> Undefined variable: area_primary C:\xampp\htdocs\service\application\controllers\api\scenario.php 86
