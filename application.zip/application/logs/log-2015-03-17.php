<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-17 09:58:11 --> Severity: Notice  --> Undefined index: HTTPS C:\xampp\htdocs\service\application\core\REST_Controller.php 502
ERROR - 2015-03-17 10:42:00 --> Severity: Notice  --> Undefined variable: user C:\xampp\htdocs\service\application\controllers\api\users.php 12
ERROR - 2015-03-17 10:42:06 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 451
ERROR - 2015-03-17 10:42:06 --> Severity: Notice  --> Undefined property: stdClass::$format C:\xampp\htdocs\service\application\core\REST_Controller.php 459
ERROR - 2015-03-17 10:42:06 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\xampp\htdocs\service\application\core\REST_Controller.php 479
ERROR - 2015-03-17 10:42:06 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\service\application\core\REST_Controller.php 488
ERROR - 2015-03-17 14:01:31 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\xampp\htdocs\service\application\core\REST_Controller.php 482
ERROR - 2015-03-17 14:01:31 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\service\application\core\REST_Controller.php 491
ERROR - 2015-03-17 14:02:24 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\xampp\htdocs\service\application\core\REST_Controller.php 482
ERROR - 2015-03-17 14:02:24 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\service\application\core\REST_Controller.php 491
ERROR - 2015-03-17 16:32:59 --> Query error: Unknown column 'id' in 'field list'
ERROR - 2015-03-17 16:33:42 --> Query error: Unknown column 'areas' in 'field list'
ERROR - 2015-03-17 16:33:54 --> Severity: Warning  --> mysqli_query(): (42000/1318): Incorrect number of arguments for FUNCTION squigy.GetFamilyTree; expected 2, got 1 C:\xampp\htdocs\service\system\database\drivers\mysqli\mysqli_driver.php 180
ERROR - 2015-03-17 16:33:54 --> Query error: Incorrect number of arguments for FUNCTION squigy.GetFamilyTree; expected 2, got 1
ERROR - 2015-03-17 16:34:14 --> Query error: Unknown column 'areas' in 'field list'
ERROR - 2015-03-17 16:34:31 --> Severity: Warning  --> mysqli_query(): (HY000/1449): The user specified as a definer ('squigy'@'localhost') does not exist C:\xampp\htdocs\service\system\database\drivers\mysqli\mysqli_driver.php 180
ERROR - 2015-03-17 16:34:31 --> Query error: The user specified as a definer ('squigy'@'localhost') does not exist
ERROR - 2015-03-17 16:35:34 --> Severity: Warning  --> mysqli_query(): (42S02/1146): Table 'squigy.tbname' doesn't exist C:\xampp\htdocs\service\system\database\drivers\mysqli\mysqli_driver.php 180
ERROR - 2015-03-17 16:35:34 --> Query error: Table 'squigy.tbname' doesn't exist
ERROR - 2015-03-17 16:38:44 --> Severity: Warning  --> mysqli_query(): (42S02/1146): Table 'squigy.tbname' doesn't exist C:\xampp\htdocs\service\system\database\drivers\mysqli\mysqli_driver.php 180
ERROR - 2015-03-17 16:38:44 --> Query error: Table 'squigy.tbname' doesn't exist
ERROR - 2015-03-17 16:42:43 --> Severity: Warning  --> mysqli_query(): (42S22/1054): Unknown column 'id' in 'field list' C:\xampp\htdocs\service\system\database\drivers\mysqli\mysqli_driver.php 180
ERROR - 2015-03-17 16:42:43 --> Query error: Unknown column 'id' in 'field list'
ERROR - 2015-03-17 16:44:52 --> Severity: Warning  --> mysqli_query(): (42000/1318): Incorrect number of arguments for FUNCTION squigy.GetFamilyTree; expected 2, got 1 C:\xampp\htdocs\service\system\database\drivers\mysqli\mysqli_driver.php 180
ERROR - 2015-03-17 16:44:52 --> Query error: Incorrect number of arguments for FUNCTION squigy.GetFamilyTree; expected 2, got 1
ERROR - 2015-03-17 16:45:04 --> Severity: Warning  --> mysqli_query(): (42S22/1054): Unknown column 'id' in 'field list' C:\xampp\htdocs\service\system\database\drivers\mysqli\mysqli_driver.php 180
ERROR - 2015-03-17 16:45:04 --> Query error: Unknown column 'id' in 'field list'
