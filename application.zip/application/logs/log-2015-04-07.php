<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-07 09:31:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE id = 1
name=kevin' at line 1
ERROR - 2015-04-07 09:31:44 --> Query error: Unknown column 'kevin' in 'field list'
ERROR - 2015-04-07 09:44:08 --> Severity: Notice  --> Undefined variable: instance C:\xampp\htdocs\service\system\core\Controller.php 49
ERROR - 2015-04-07 09:44:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\service\system\core\Controller.php:49) C:\xampp\htdocs\service\application\core\REST_Controller.php 476
ERROR - 2015-04-07 09:44:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\service\system\core\Controller.php:49) C:\xampp\htdocs\service\system\core\Common.php 443
ERROR - 2015-04-07 09:44:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\service\system\core\Controller.php:49) C:\xampp\htdocs\service\application\core\REST_Controller.php 494
ERROR - 2015-04-07 09:44:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\service\system\core\Controller.php:50) C:\xampp\htdocs\service\application\core\REST_Controller.php 476
ERROR - 2015-04-07 09:44:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\service\system\core\Controller.php:50) C:\xampp\htdocs\service\system\core\Common.php 443
ERROR - 2015-04-07 09:44:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\service\system\core\Controller.php:50) C:\xampp\htdocs\service\application\core\REST_Controller.php 494
ERROR - 2015-04-07 09:48:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\service\system\core\Controller.php:50) C:\xampp\htdocs\service\application\core\REST_Controller.php 475
ERROR - 2015-04-07 09:48:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\service\system\core\Controller.php:50) C:\xampp\htdocs\service\system\core\Common.php 443
ERROR - 2015-04-07 09:48:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\service\system\core\Controller.php:50) C:\xampp\htdocs\service\application\core\REST_Controller.php 493
ERROR - 2015-04-07 09:48:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\service\system\core\Controller.php:50) C:\xampp\htdocs\service\application\core\REST_Controller.php 475
ERROR - 2015-04-07 09:48:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\service\system\core\Controller.php:50) C:\xampp\htdocs\service\system\core\Common.php 443
ERROR - 2015-04-07 09:48:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\service\system\core\Controller.php:50) C:\xampp\htdocs\service\application\core\REST_Controller.php 493
ERROR - 2015-04-07 11:04:21 --> Severity: Notice  --> Undefined property: SapInterfacer::$CompanyName C:\xampp\htdocs\service\application\controllers\api\bp.php 11
ERROR - 2015-04-07 12:10:09 --> Severity: Notice  --> Undefined variable: sapCom C:\xampp\htdocs\service\application\controllers\api\bp.php 42
ERROR - 2015-04-07 12:57:42 --> Severity: Notice  --> Undefined variable: rua9883 C:\xampp\htdocs\service\application\controllers\api\bp.php 55
ERROR - 2015-04-07 13:08:25 --> 404 Page Not Found --> api/get_client
ERROR - 2015-04-07 13:53:53 --> Severity: Notice  --> Undefined index: CardCode C:\xampp\htdocs\service\application\controllers\api\bp.php 54
ERROR - 2015-04-07 14:30:27 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\service\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2015-04-07 14:30:27 --> Unable to connect to the database
ERROR - 2015-04-07 14:40:54 --> Severity: Notice  --> Undefined variable: CardCode C:\xampp\htdocs\service\application\controllers\api\bp.php 34
ERROR - 2015-04-07 14:42:10 --> Severity: Notice  --> Undefined variable: CardCode C:\xampp\htdocs\service\application\controllers\api\bp.php 34
ERROR - 2015-04-07 14:45:12 --> Severity: Notice  --> Undefined variable: error C:\xampp\htdocs\service\application\controllers\api\bp.php 23
ERROR - 2015-04-07 14:45:13 --> Severity: Notice  --> Undefined variable: error C:\xampp\htdocs\service\application\controllers\api\bp.php 23
ERROR - 2015-04-07 15:19:46 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\service\application\controllers\api\bp.php 71
ERROR - 2015-04-07 15:19:46 --> Severity: Warning  --> Attempt to assign property of non-object C:\xampp\htdocs\service\application\controllers\api\bp.php 71
ERROR - 2015-04-07 15:20:42 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\service\application\controllers\api\bp.php 73
ERROR - 2015-04-07 15:20:42 --> Severity: Warning  --> Attempt to assign property of non-object C:\xampp\htdocs\service\application\controllers\api\bp.php 73
ERROR - 2015-04-07 15:21:24 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\service\application\controllers\api\bp.php 71
ERROR - 2015-04-07 15:21:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\xampp\htdocs\service\application\controllers\api\bp.php 71
ERROR - 2015-04-07 15:22:30 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\service\application\controllers\api\bp.php 75
ERROR - 2015-04-07 15:22:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\xampp\htdocs\service\application\controllers\api\bp.php 75
ERROR - 2015-04-07 15:23:17 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\service\application\controllers\api\bp.php 73
ERROR - 2015-04-07 15:25:41 --> Severity: Warning  --> Creating default object from empty value C:\xampp\htdocs\service\application\controllers\api\bp.php 71
ERROR - 2015-04-07 15:26:21 --> Severity: Warning  --> Creating default object from empty value C:\xampp\htdocs\service\application\controllers\api\bp.php 71
ERROR - 2015-04-07 15:47:27 --> Severity: Notice  --> Undefined variable: variable C:\xampp\htdocs\service\application\controllers\api\bp.php 35
ERROR - 2015-04-07 15:47:27 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\service\application\controllers\api\bp.php 35
ERROR - 2015-04-07 15:47:27 --> Severity: Notice  --> Undefined variable: CardCode C:\xampp\htdocs\service\application\controllers\api\bp.php 38
ERROR - 2015-04-07 15:48:03 --> Severity: Notice  --> Undefined variable: CardCode C:\xampp\htdocs\service\application\controllers\api\bp.php 35
