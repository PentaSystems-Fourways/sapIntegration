<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-04 09:20:05 --> Severity: Notice  --> Undefined variable: sapInfResponse C:\xampp\htdocs\service\application\controllers\api\gr.php 26
ERROR - 2015-05-04 09:26:32 --> Severity: Warning  --> Missing argument 1 for SapInterfacer::get_error(), called in C:\xampp\htdocs\service\application\libraries\SapInterfacer.php on line 34 and defined C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 56
ERROR - 2015-05-04 09:26:32 --> Severity: Notice  --> Undefined variable: errCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 59
ERROR - 2015-05-04 11:11:56 --> Severity: Warning  --> Missing argument 1 for SapInterfacer::get_error(), called in C:\xampp\htdocs\service\application\libraries\SapInterfacer.php on line 34 and defined C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 56
ERROR - 2015-05-04 11:11:56 --> Severity: Notice  --> Undefined variable: errCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 59
ERROR - 2015-05-04 13:59:57 --> Severity: Warning  --> Missing argument 1 for SapInterfacer::get_error(), called in C:\xampp\htdocs\service\application\libraries\SapInterfacer.php on line 34 and defined C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 61
ERROR - 2015-05-04 13:59:57 --> Severity: Notice  --> Undefined variable: errCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 64
ERROR - 2015-05-04 14:00:02 --> Severity: Warning  --> Missing argument 1 for SapInterfacer::get_error(), called in C:\xampp\htdocs\service\application\libraries\SapInterfacer.php on line 34 and defined C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 61
ERROR - 2015-05-04 14:00:02 --> Severity: Notice  --> Undefined variable: errCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 64
ERROR - 2015-05-04 14:00:03 --> Severity: Warning  --> Missing argument 1 for SapInterfacer::get_error(), called in C:\xampp\htdocs\service\application\libraries\SapInterfacer.php on line 34 and defined C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 61
ERROR - 2015-05-04 14:00:03 --> Severity: Notice  --> Undefined variable: errCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 64
ERROR - 2015-05-04 14:00:05 --> Severity: Warning  --> Missing argument 1 for SapInterfacer::get_error(), called in C:\xampp\htdocs\service\application\libraries\SapInterfacer.php on line 34 and defined C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 61
ERROR - 2015-05-04 14:00:05 --> Severity: Notice  --> Undefined variable: errCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 64
ERROR - 2015-05-04 14:00:06 --> Severity: Warning  --> Missing argument 1 for SapInterfacer::get_error(), called in C:\xampp\htdocs\service\application\libraries\SapInterfacer.php on line 34 and defined C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 61
ERROR - 2015-05-04 14:00:06 --> Severity: Notice  --> Undefined variable: errCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 64
ERROR - 2015-05-04 14:00:08 --> Severity: Warning  --> Missing argument 1 for SapInterfacer::get_error(), called in C:\xampp\htdocs\service\application\libraries\SapInterfacer.php on line 34 and defined C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 61
ERROR - 2015-05-04 14:00:08 --> Severity: Notice  --> Undefined variable: errCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 64
ERROR - 2015-05-04 14:00:19 --> Severity: Warning  --> Missing argument 1 for SapInterfacer::get_error(), called in C:\xampp\htdocs\service\application\libraries\SapInterfacer.php on line 34 and defined C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 61
ERROR - 2015-05-04 14:00:19 --> Severity: Notice  --> Undefined variable: errCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 64
ERROR - 2015-05-04 14:40:20 --> Severity: Warning  --> Missing argument 1 for SapInterfacer::get_error(), called in C:\xampp\htdocs\service\application\libraries\SapInterfacer.php on line 34 and defined C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 61
ERROR - 2015-05-04 14:40:20 --> Severity: Notice  --> Undefined variable: errCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 64
ERROR - 2015-05-04 16:54:26 --> Severity: Notice  --> Undefined variable: sapInfResponse C:\xampp\htdocs\service\application\controllers\api\wt.php 24
ERROR - 2015-05-04 17:01:25 --> Severity: Warning  --> Missing argument 1 for SapInterfacer::get_error(), called in C:\xampp\htdocs\service\application\controllers\api\wt.php on line 24 and defined C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 61
ERROR - 2015-05-04 17:01:25 --> Severity: Notice  --> Undefined variable: errCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 64
ERROR - 2015-05-04 17:01:30 --> Severity: Warning  --> Missing argument 1 for SapInterfacer::get_error(), called in C:\xampp\htdocs\service\application\controllers\api\wt.php on line 24 and defined C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 61
ERROR - 2015-05-04 17:01:30 --> Severity: Notice  --> Undefined variable: errCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 64
ERROR - 2015-05-04 17:01:40 --> Severity: Warning  --> Missing argument 1 for SapInterfacer::get_error(), called in C:\xampp\htdocs\service\application\controllers\api\wt.php on line 24 and defined C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 61
ERROR - 2015-05-04 17:01:40 --> Severity: Notice  --> Undefined variable: errCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 64
ERROR - 2015-05-04 17:02:12 --> Severity: Warning  --> Missing argument 1 for SapInterfacer::get_error(), called in C:\xampp\htdocs\service\application\controllers\api\wt.php on line 24 and defined C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 61
ERROR - 2015-05-04 17:02:12 --> Severity: Notice  --> Undefined variable: errCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 64
