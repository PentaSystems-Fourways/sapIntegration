<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-14 11:34:06 --> Severity: Notice  --> Undefined variable: quotationList C:\xampp\htdocs\service\application\controllers\api\op.php 14
ERROR - 2015-04-14 11:34:06 --> Severity: Notice  --> Undefined variable: errMsg C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 66
ERROR - 2015-04-14 15:40:02 --> Severity: Notice  --> Undefined variable: opputunityList C:\xampp\htdocs\service\application\controllers\api\op.php 29
ERROR - 2015-04-14 15:40:57 --> Severity: Notice  --> Undefined variable: opputunityList C:\xampp\htdocs\service\application\controllers\api\op.php 29
ERROR - 2015-04-14 15:41:36 --> Severity: Notice  --> Undefined variable: opputunityList C:\xampp\htdocs\service\application\controllers\api\op.php 29
ERROR - 2015-04-14 15:42:44 --> Severity: Notice  --> Undefined index: OpprId C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 96
