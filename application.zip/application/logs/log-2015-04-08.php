<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-08 12:09:38 --> Severity: Warning  --> Missing argument 1 for SapInterfacer::_update(), called in C:\xampp\htdocs\service\application\controllers\api\bp.php on line 92 and defined C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 52
ERROR - 2015-04-08 12:09:38 --> Severity: Notice  --> Undefined variable: UpdatedList C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 54
ERROR - 2015-04-08 12:09:38 --> Severity: Notice  --> Undefined variable: UpdatedList C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 55
ERROR - 2015-04-08 12:09:38 --> Severity: Notice  --> Undefined variable: errMsg C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 55
ERROR - 2015-04-08 12:10:34 --> Severity: Warning  --> Creating default object from empty value C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 71
ERROR - 2015-04-08 12:10:34 --> Severity: Warning  --> Creating default object from empty value C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 73
ERROR - 2015-04-08 12:42:46 --> Severity: Notice  --> Undefined variable: errMsg C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 101
ERROR - 2015-04-08 12:49:25 --> Severity: Notice  --> Undefined index: CardCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 91
ERROR - 2015-04-08 12:49:25 --> Severity: Notice  --> Undefined variable: errMsg C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 91
ERROR - 2015-04-08 13:28:37 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 146
ERROR - 2015-04-08 13:29:13 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 146
ERROR - 2015-04-08 13:38:20 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 146
ERROR - 2015-04-08 13:38:32 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 146
ERROR - 2015-04-08 13:54:20 --> Severity: Notice  --> Undefined property: SapInterfacer::$bp C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 64
ERROR - 2015-04-08 14:05:11 --> Severity: Notice  --> Undefined variable: errMsg C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 74
ERROR - 2015-04-08 15:41:22 --> Severity: Notice  --> Undefined variable: BoAddressType C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 134
