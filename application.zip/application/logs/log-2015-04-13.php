<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-13 10:06:45 --> Severity: Notice  --> Undefined variable: RetCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 119
ERROR - 2015-04-13 10:06:53 --> Severity: Notice  --> Undefined variable: RetCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 119
ERROR - 2015-04-13 10:16:11 --> Severity: Notice  --> Undefined variable: RetCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 119
ERROR - 2015-04-13 11:03:57 --> Severity: Notice  --> Undefined variable: errors C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 157
ERROR - 2015-04-13 11:05:30 --> Severity: Notice  --> Undefined variable: errors C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 160
ERROR - 2015-04-13 11:06:11 --> Severity: Notice  --> Undefined property: SapInterfacer::$errors C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 160
