<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-30 10:35:34 --> Severity: Notice  --> Undefined variable: sapInfResponse C:\xampp\htdocs\service\application\controllers\api\gr.php 22
ERROR - 2015-04-30 12:19:51 --> Severity: Warning  --> Missing argument 1 for SapInterfacer::get_error(), called in C:\xampp\htdocs\service\application\libraries\SapInterfacer.php on line 34 and defined C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 56
ERROR - 2015-04-30 12:19:51 --> Severity: Notice  --> Undefined variable: errCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 59
ERROR - 2015-04-30 12:32:21 --> Severity: Notice  --> Use of undefined constant DDC53L13000510 - assumed 'DDC53L13000510' C:\xampp\htdocs\service\application\controllers\api\gr.php 21
ERROR - 2015-04-30 12:54:32 --> Severity: Warning  --> Missing argument 1 for SapInterfacer::get_error(), called in C:\xampp\htdocs\service\application\libraries\SapInterfacer.php on line 34 and defined C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 56
ERROR - 2015-04-30 12:54:32 --> Severity: Notice  --> Undefined variable: errCode C:\xampp\htdocs\service\application\libraries\SapInterfacer.php 59
