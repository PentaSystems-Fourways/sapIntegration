<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-19 13:53:35 --> Severity: Warning  --> Missing argument 1 for Areas::countries_get() C:\xampp\htdocs\service\application\controllers\api\areas.php 10
ERROR - 2015-03-19 13:53:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\service\application\controllers\api\areas.php 11
ERROR - 2015-03-19 13:53:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2015-03-19 13:53:43 --> Severity: Warning  --> mysqli_query(): (42S22/1054): Unknown column 'parent_id' in 'where clause' C:\xampp\htdocs\service\system\database\drivers\mysqli\mysqli_driver.php 180
ERROR - 2015-03-19 13:53:43 --> Query error: Unknown column 'parent_id' in 'where clause'
ERROR - 2015-03-19 13:57:07 --> Query error: FUNCTION squigy.GetFamilyTree does not exist
ERROR - 2015-03-19 14:05:56 --> Query error: Unknown column 'b.id' in 'field list'
ERROR - 2015-03-19 14:07:14 --> Query error: Unknown column 'a.area_name' in 'field list'
ERROR - 2015-03-19 14:11:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 4
ERROR - 2015-03-19 14:45:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE parent_id IN($areas)' at line 1
ERROR - 2015-03-19 14:46:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE parent_id IN($areas)' at line 1
ERROR - 2015-03-19 14:47:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE parent_id IN(259)' at line 1
ERROR - 2015-03-19 14:56:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1 - R 4800,sum(t2),sum(t3),sum(t4),sum(t5),sum(t6),sum(t7),sum(t8),sum(t9),sum(t' at line 1
ERROR - 2015-03-19 15:25:05 --> Severity: Warning  --> array_slice() expects parameter 1 to be array, object given C:\xampp\htdocs\service\application\controllers\api\scenario.php 20
ERROR - 2015-03-19 15:25:05 --> Severity: Warning  --> array_sum() expects parameter 1 to be array, null given C:\xampp\htdocs\service\application\controllers\api\scenario.php 20
ERROR - 2015-03-19 15:25:05 --> Severity: Warning  --> array_slice() expects parameter 1 to be array, object given C:\xampp\htdocs\service\application\controllers\api\scenario.php 20
ERROR - 2015-03-19 15:25:05 --> Severity: Warning  --> array_sum() expects parameter 1 to be array, null given C:\xampp\htdocs\service\application\controllers\api\scenario.php 20
ERROR - 2015-03-19 15:25:05 --> Severity: Warning  --> array_slice() expects parameter 1 to be array, object given C:\xampp\htdocs\service\application\controllers\api\scenario.php 20
ERROR - 2015-03-19 15:25:05 --> Severity: Warning  --> array_sum() expects parameter 1 to be array, null given C:\xampp\htdocs\service\application\controllers\api\scenario.php 20
ERROR - 2015-03-19 15:25:08 --> Severity: Warning  --> array_slice() expects parameter 1 to be array, object given C:\xampp\htdocs\service\application\controllers\api\scenario.php 20
ERROR - 2015-03-19 15:25:08 --> Severity: Warning  --> array_sum() expects parameter 1 to be array, null given C:\xampp\htdocs\service\application\controllers\api\scenario.php 20
ERROR - 2015-03-19 15:25:08 --> Severity: Warning  --> array_slice() expects parameter 1 to be array, object given C:\xampp\htdocs\service\application\controllers\api\scenario.php 20
ERROR - 2015-03-19 15:25:08 --> Severity: Warning  --> array_sum() expects parameter 1 to be array, null given C:\xampp\htdocs\service\application\controllers\api\scenario.php 20
ERROR - 2015-03-19 15:29:30 --> Severity: Warning  --> array_slice() expects parameter 1 to be array, object given C:\xampp\htdocs\service\application\controllers\api\scenario.php 21
ERROR - 2015-03-19 15:29:30 --> Severity: Warning  --> array_slice() expects parameter 1 to be array, object given C:\xampp\htdocs\service\application\controllers\api\scenario.php 21
ERROR - 2015-03-19 15:31:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\service\application\controllers\api\scenario.php 27
ERROR - 2015-03-19 15:31:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\service\application\controllers\api\scenario.php 27
ERROR - 2015-03-19 15:38:38 --> Severity: Notice  --> Undefined variable: array C:\xampp\htdocs\service\application\controllers\api\scenario.php 21
ERROR - 2015-03-19 15:38:38 --> Severity: Notice  --> Undefined variable: array C:\xampp\htdocs\service\application\controllers\api\scenario.php 21
