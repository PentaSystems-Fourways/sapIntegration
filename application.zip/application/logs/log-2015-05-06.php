<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-06 14:48:30 --> Severity: Notice  --> Undefined property: Bp::$sapinterfacer C:\xampp\htdocs\service\application\controllers\api\bp.php 9
