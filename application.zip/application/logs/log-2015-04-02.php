<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-02 11:39:50 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\service\system\core\Common.php 257
ERROR - 2015-04-02 11:39:50 --> 404 Page Not Found --> api/users
ERROR - 2015-04-02 11:45:51 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\service\system\core\Common.php 257
ERROR - 2015-04-02 12:03:54 --> Severity: Warning  --> mysqli_connect(): (HY000/1049): Unknown database 'pentasystem' C:\xampp\htdocs\service\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2015-04-02 12:03:54 --> Unable to connect to the database
ERROR - 2015-04-02 12:04:52 --> Severity: Warning  --> mysqli_connect(): (HY000/1049): Unknown database 'pentasystem' C:\xampp\htdocs\service\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2015-04-02 12:04:52 --> Unable to connect to the database
ERROR - 2015-04-02 12:05:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-04-02 12:05:44 --> Unable to select database: pentasystem
ERROR - 2015-04-02 12:05:55 --> Severity: Warning  --> mysqli_connect(): (HY000/1049): Unknown database 'pentasystem' C:\xampp\htdocs\service\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2015-04-02 12:05:55 --> Unable to connect to the database
ERROR - 2015-04-02 12:09:36 --> Severity: Warning  --> mysqli_connect(): (HY000/1049): Unknown database 'pentasystem' C:\xampp\htdocs\service\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2015-04-02 12:09:36 --> Unable to connect to the database
ERROR - 2015-04-02 12:09:37 --> Severity: Warning  --> mysqli_connect(): (HY000/1049): Unknown database 'pentasystem' C:\xampp\htdocs\service\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2015-04-02 12:09:37 --> Unable to connect to the database
ERROR - 2015-04-02 12:12:33 --> Severity: Warning  --> mysqli_connect(): (HY000/1049): Unknown database 'pentasystem' C:\xampp\htdocs\service\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2015-04-02 12:12:33 --> Unable to connect to the database
ERROR - 2015-04-02 12:15:11 --> Severity: Warning  --> mysqli_connect(): (HY000/1049): Unknown database 'pentasyste' C:\xampp\htdocs\service\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2015-04-02 12:15:11 --> Unable to connect to the database
ERROR - 2015-04-02 12:15:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-04-02 12:15:18 --> Unable to select database: pentasyst
ERROR - 2015-04-02 12:15:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-04-02 12:15:25 --> Unable to select database: pentasystem
ERROR - 2015-04-02 12:16:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-04-02 12:16:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-04-02 12:20:44 --> Query error: Column count doesn't match value count at row 1
ERROR - 2015-04-02 12:21:08 --> Query error: Unknown column 'Cyril' in 'field list'
